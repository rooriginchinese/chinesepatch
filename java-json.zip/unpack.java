package unpack;
import java.io.*;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class unpack {

	public static void main(String[] args) {
		try {
			File f = new File("C:\\Users\\Daniel\\eclipse-workspace\\unpack\\src\\unpack\\2226754682.robytes");
			byte[] bArr = Files.readAllBytes(f.toPath());
			Database DatabaseUnpack = DatabaseUnpack(bArr);
			
			LinkedHashMap<Long, String> rootMap = DatabaseToRoot(DatabaseUnpack.items);
			
			JSONObject json = new JSONObject(rootMap);
	        String jsonString = json.toString();

            Writer out = new BufferedWriter(new OutputStreamWriter(
            	    new FileOutputStream("C:\\Users\\Daniel\\eclipse-workspace\\unpack\\src\\unpack\\2226754682.txt"), "UTF-8"));
            	try {
            	    out.write(jsonString);
            	} finally {
            	    out.close();
            	}
//            byte[] DatabasePack = DatabasePack(DatabaseUnpack);
//			WriteFile("C:\\Users\\Daniel\\eclipse-workspace\\unpack\\src\\unpack\\2226754682_new.robytes", DatabasePack);
		}
		catch(Exception e) {

		}
	}
	
    public static class DatabaseItem {

        /* renamed from: id */
        long f88id;
        String text;
    }
    
    public static class Database {
        int count;
        LinkedHashMap<Long, DatabaseItem> items = new LinkedHashMap<>();
        int unknown1;
        int unknown2;
    }
    
	public static Database DatabaseUnpack(byte[] bArr) {
	    Database database = new Database();
	    if (bArr.length == 0) {
	        return database;
	    }
	    Buffer.Payload payload = new Buffer.Payload();
	    database.count = Buffer.GetInt(bArr, payload);
	    for (int i = 0; i < database.count; i++) {
	        DatabaseItem databaseItem = new DatabaseItem();
	        databaseItem.f88id = Convert.Unsigned(Buffer.GetInt(bArr, payload));
	        databaseItem.text = Buffer.GetString(bArr, payload);
	        database.items.put(Long.valueOf(databaseItem.f88id), databaseItem);
	    }
	    database.unknown1 = Buffer.GetInt(bArr, payload);
	    database.unknown2 = Buffer.GetInt(bArr, payload);
	    return database;
	}
    
    public static LinkedHashMap<Long, String> DatabaseToRoot(LinkedHashMap<Long, DatabaseItem> linkedHashMap) {
		LinkedHashMap<Long, String> rootMap = new LinkedHashMap<>();
        for (Map.Entry next : linkedHashMap.entrySet()) {
            Long l = (Long) next.getKey();
            DatabaseItem databaseItem = (DatabaseItem) next.getValue();
            rootMap.put(l,databaseItem.text);
        }
        return rootMap;
    }
}
